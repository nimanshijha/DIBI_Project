def replace_path(new_path):#example 'C:/Users/niman/Desktop/FolderName'

    fin = open(r"C:\Users\niman\Desktop\code\Macro_35_0gy_2h_p6_watershed.ijm", "rt") #give location of where ijm files are stored
    fout = open(r"C:\Users\niman\Desktop\code\Path_Macro_35_0gy_2h_p6_watershed.ijm", "wt")#path of new new ijm files
    for line in fin:
        fout.write(line.replace('C:/Users/niman/Desktop/dibi', new_path))
    fin.close()
    fout.close()

    return(print('Paths Successfully replaced!'))