from img_process import *

def main():
    #read image
    image = cv2.imread(r'C:\Users\niman\Desktop\DIBI_Project\35_0gy_2h_p6.tif')
    path = 'niman/Desktop'#give path like this 

    obj1=Image_processing(image,path)

if __name__ == "__main__":
    main()
