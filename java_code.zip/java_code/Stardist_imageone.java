import ij.IJ;
import ij.plugin.PlugIn;
import org.scijava.script.ScriptService;
import ij.macro.Interpreter;
import java.io.*;


public class Stardist_imageone implements PlugIn {
    @Override
    public void run(String arg) {
         IJ.runMacroFile("C:/Users/niman/Desktop/dibi/macros/Macro_35_0gy_2h_p6_Stardist.ijm");
    }
}